
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, Briefcase, CalendarDays, UserCog, LogOut, Moon, Sun, Edit2, Trash2, PlusCircle, Send } from 'lucide-react';
import { format, differenceInMinutes, parseISO } from 'date-fns';

const initialEmployees = [
  { id: 'emp1', name: 'Max Mustermann', role: 'employee' },
  { id: 'emp2', name: 'Erika Mustermann', role: 'employee' },
  { id: 'admin1', name: 'Admin Boss', role: 'admin' },
];

const initialTimeEntries = [
  { id: 'time1', employeeId: 'emp1', startTime: '2025-05-08T08:00:00Z', endTime: '2025-05-08T16:30:00Z', breakDuration: 30 },
  { id: 'time2', employeeId: 'emp2', startTime: '2025-05-08T09:15:00Z', endTime: '2025-05-08T17:45:00Z', breakDuration: 45 },
];

const initialVacationRequests = [
  { id: 'vac1', employeeId: 'emp1', startDate: '2025-06-10', endDate: '2025-06-14', status: 'Pending' },
];

function App() {
  const [currentUser, setCurrentUser] = React.useState(null); 
  const [theme, setTheme] = React.useState(localStorage.getItem('theme') || 'light');
  const { toast } = useToast();

  React.useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const handleLogin = (userId) => {
    const user = initialEmployees.find(emp => emp.id === userId);
    if (user) {
      setCurrentUser(user);
      toast({ title: "Anmeldung erfolgreich", description: `Willkommen, ${user.name}!` });
    } else {
      toast({ variant: "destructive", title: "Anmeldung fehlgeschlagen", description: "Benutzer nicht gefunden." });
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    toast({ title: "Abmeldung erfolgreich" });
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-600 via-indigo-500 to-blue-500 p-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <Card className="glassmorphism shadow-2xl">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold text-white">Zeiterfassung</CardTitle>
              <CardDescription className="text-purple-200">Bitte wählen Sie Ihren Benutzer aus</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {initialEmployees.map(emp => (
                <Button key={emp.id} onClick={() => handleLogin(emp.id)} className="w-full bg-white/20 hover:bg-white/30 text-white font-semibold py-3 text-lg">
                  {emp.name} ({emp.role})
                </Button>
              ))}
            </CardContent>
          </Card>
        </motion.div>
        <Toaster />
      </div>
    );
  }
  
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-slate-50">
        <Header currentUser={currentUser} onLogout={handleLogout} toggleTheme={toggleTheme} currentTheme={theme} />
        <main className="flex-grow container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={currentUser.role === 'admin' ? <Navigate to="/admin" /> : <Navigate to="/employee" />} />
            <Route path="/employee" element={currentUser.role === 'employee' ? <EmployeeDashboard currentUser={currentUser} /> : <Navigate to="/admin" />} />
            <Route path="/admin" element={currentUser.role === 'admin' ? <AdminDashboard /> : <Navigate to="/employee" />} />
            <Route path="/vacation" element={<VacationRequestPage currentUser={currentUser} />} />
          </Routes>
        </main>
        <Toaster />
      </div>
    </Router>
  );
}

function Header({ currentUser, onLogout, toggleTheme, currentTheme }) {
  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 120 }}
      className="bg-slate-800/50 backdrop-blur-md shadow-lg p-4"
    >
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
          Zeiterfassung Pro
        </Link>
        <nav className="flex items-center space-x-4">
          {currentUser.role === 'employee' && (
            <>
              <NavLink to="/employee">Dashboard</NavLink>
              <NavLink to="/vacation">Urlaub</NavLink>
            </>
          )}
          {currentUser.role === 'admin' && (
            <>
              <NavLink to="/admin">Admin Dashboard</NavLink>
              <NavLink to="/vacation">Urlaubsanträge</NavLink>
            </>
          )}
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="hover:bg-purple-500/20">
            {currentTheme === 'light' ? <Moon className="h-5 w-5 text-purple-400" /> : <Sun className="h-5 w-5 text-yellow-400" />}
          </Button>
          <Button onClick={onLogout} variant="ghost" className="text-purple-400 hover:text-pink-500 hover:bg-purple-500/20">
            <LogOut className="mr-2 h-5 w-5" /> Abmelden
          </Button>
        </nav>
      </div>
    </motion.header>
  );
}

function NavLink({ to, children }) {
  return (
    <Link to={to} className="px-3 py-2 rounded-md text-sm font-medium text-slate-300 hover:bg-purple-700 hover:text-white transition-colors">
      {children}
    </Link>
  );
}

function EmployeeDashboard({ currentUser }) {
  const { toast } = useToast();
  const [timeEntries, setTimeEntries] = React.useState(() => JSON.parse(localStorage.getItem(`timeEntries_${currentUser.id}`)) || []);
  const [currentEntry, setCurrentEntry] = React.useState(() => JSON.parse(localStorage.getItem(`currentEntry_${currentUser.id}`)) || null);

  React.useEffect(() => {
    localStorage.setItem(`timeEntries_${currentUser.id}`, JSON.stringify(timeEntries));
  }, [timeEntries, currentUser.id]);

  React.useEffect(() => {
    localStorage.setItem(`currentEntry_${currentUser.id}`, JSON.stringify(currentEntry));
  }, [currentEntry, currentUser.id]);

  const handleClockIn = () => {
    if (currentEntry) {
      toast({ variant: "destructive", title: "Fehler", description: "Sie sind bereits eingestempelt." });
      return;
    }
    const newEntry = { id: `time_${Date.now()}`, employeeId: currentUser.id, startTime: new Date().toISOString(), endTime: null, breakDuration: 0 };
    setCurrentEntry(newEntry);
    toast({ title: "Eingestempelt", description: `Arbeitsbeginn um ${format(new Date(newEntry.startTime), 'HH:mm')}` });
  };

  const handleClockOut = () => {
    if (!currentEntry) {
      toast({ variant: "destructive", title: "Fehler", description: "Sie sind nicht eingestempelt." });
      return;
    }
    // Simple break calculation for demo. German law is complex.
    // 6 hours -> 30 min break, 9 hours -> 45 min break
    const workDurationMinutes = differenceInMinutes(new Date(), new Date(currentEntry.startTime));
    let breakMinutes = 0;
    if (workDurationMinutes > 9 * 60) {
      breakMinutes = 45;
    } else if (workDurationMinutes > 6 * 60) {
      breakMinutes = 30;
    }

    const completedEntry = { ...currentEntry, endTime: new Date().toISOString(), breakDuration: breakMinutes };
    setTimeEntries(prev => [completedEntry, ...prev]);
    setCurrentEntry(null);
    toast({ title: "Ausgestempelt", description: `Arbeitsende um ${format(new Date(completedEntry.endTime), 'HH:mm')}. Pause: ${breakMinutes} Min.` });
  };
  
  const calculateWorkDuration = (startTime, endTime, breakDuration) => {
    if (!endTime) return "Laufend";
    const durationMs = new Date(endTime).getTime() - new Date(startTime).getTime();
    const netDurationMinutes = Math.max(0, (durationMs / (1000 * 60)) - breakDuration);
    const hours = Math.floor(netDurationMinutes / 60);
    const minutes = Math.round(netDurationMinutes % 60);
    return `${hours} Std. ${minutes} Min.`;
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
      <Card className="glassmorphism shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center"><Clock className="mr-2 h-6 w-6 text-purple-400" />Meine Zeiterfassung</CardTitle>
          <CardDescription>Stempeln Sie Ihre Arbeitszeiten und sehen Sie Ihre Einträge.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex space-x-4">
            <Button onClick={handleClockIn} disabled={!!currentEntry} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-3 text-lg">
              <Clock className="mr-2 h-5 w-5" /> Kommen
            </Button>
            <Button onClick={handleClockOut} disabled={!currentEntry} className="flex-1 bg-red-500 hover:bg-red-600 text-white py-3 text-lg">
              <LogOut className="mr-2 h-5 w-5" /> Gehen
            </Button>
          </div>
          {currentEntry && (
            <div className="p-4 bg-purple-500/10 rounded-lg text-center">
              <p className="font-semibold text-purple-300">Aktuell eingestempelt seit: {format(new Date(currentEntry.startTime), 'dd.MM.yyyy HH:mm')}</p>
            </div>
          )}
          <div>
            <h3 className="text-xl font-semibold mb-2 text-purple-300">Meine Einträge</h3>
            {timeEntries.length === 0 ? (
              <p className="text-slate-400">Noch keine Einträge vorhanden.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Datum</TableHead>
                    <TableHead>Start</TableHead>
                    <TableHead>Ende</TableHead>
                    <TableHead>Pause</TableHead>
                    <TableHead>Dauer</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {timeEntries.map(entry => (
                    <TableRow key={entry.id}>
                      <TableCell>{format(new Date(entry.startTime), 'dd.MM.yyyy')}</TableCell>
                      <TableCell>{format(new Date(entry.startTime), 'HH:mm')}</TableCell>
                      <TableCell>{entry.endTime ? format(new Date(entry.endTime), 'HH:mm') : '-'}</TableCell>
                      <TableCell>{entry.breakDuration} Min.</TableCell>
                      <TableCell>{calculateWorkDuration(entry.startTime, entry.endTime, entry.breakDuration)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function AdminDashboard() {
  const { toast } = useToast();
  const [allTimeEntries, setAllTimeEntries] = React.useState(() => {
    let entries = [];
    initialEmployees.forEach(emp => {
      const empEntries = JSON.parse(localStorage.getItem(`timeEntries_${emp.id}`)) || [];
      entries = [...entries, ...empEntries.map(e => ({...e, employeeName: emp.name}))];
    });
    return entries.sort((a, b) => new Date(b.startTime) - new Date(a.startTime));
  });

  const [allVacationRequests, setAllVacationRequests] = React.useState(() => {
     let requests = [];
    initialEmployees.forEach(emp => {
      const empRequests = JSON.parse(localStorage.getItem(`vacationRequests_${emp.id}`)) || [];
      requests = [...requests, ...empRequests.map(r => ({...r, employeeName: emp.name}))];
    });
    return requests.sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
  });

  const [editingEntry, setEditingEntry] = React.useState(null);
  const [formData, setFormData] = React.useState({ startTime: '', endTime: '', breakDuration: '' });

  const handleEdit = (entry) => {
    setEditingEntry(entry);
    setFormData({
      startTime: format(parseISO(entry.startTime), "yyyy-MM-dd'T'HH:mm"),
      endTime: entry.endTime ? format(parseISO(entry.endTime), "yyyy-MM-dd'T'HH:mm") : '',
      breakDuration: entry.breakDuration.toString()
    });
  };

  const handleSaveEdit = () => {
    if (!editingEntry) return;

    const updatedEntries = allTimeEntries.map(entry =>
      entry.id === editingEntry.id
        ? {
            ...entry,
            startTime: new Date(formData.startTime).toISOString(),
            endTime: formData.endTime ? new Date(formData.endTime).toISOString() : null,
            breakDuration: parseInt(formData.breakDuration, 10) || 0,
          }
        : entry
    );
    
    const userEntries = updatedEntries.filter(e => e.employeeId === editingEntry.employeeId);
    localStorage.setItem(`timeEntries_${editingEntry.employeeId}`, JSON.stringify(userEntries.map(({employeeName, ...rest}) => rest)));
    
    setAllTimeEntries(updatedEntries.sort((a, b) => new Date(b.startTime) - new Date(a.startTime)));
    setEditingEntry(null);
    toast({ title: "Erfolg", description: "Zeiteintrag aktualisiert." });
  };
  
  const handleDelete = (entryToDelete) => {
    const updatedEntries = allTimeEntries.filter(entry => entry.id !== entryToDelete.id);
    
    const userEntries = updatedEntries.filter(e => e.employeeId === entryToDelete.employeeId);
    localStorage.setItem(`timeEntries_${entryToDelete.employeeId}`, JSON.stringify(userEntries.map(({employeeName, ...rest}) => rest)));

    setAllTimeEntries(updatedEntries.sort((a, b) => new Date(b.startTime) - new Date(a.startTime)));
    toast({ title: "Erfolg", description: "Zeiteintrag gelöscht." });
  };

  const handleVacationStatusChange = (requestId, newStatus) => {
    const updatedRequests = allVacationRequests.map(req => {
      if (req.id === requestId) {
        const originalRequest = (JSON.parse(localStorage.getItem(`vacationRequests_${req.employeeId}`)) || []).find(r => r.id === requestId);
        if (originalRequest) {
          const updatedOriginal = {...originalRequest, status: newStatus};
          const userRequests = (JSON.parse(localStorage.getItem(`vacationRequests_${req.employeeId}`)) || []).map(r => r.id === requestId ? updatedOriginal : r);
          localStorage.setItem(`vacationRequests_${req.employeeId}`, JSON.stringify(userRequests));
        }
        return { ...req, status: newStatus };
      }
      return req;
    });
    setAllVacationRequests(updatedRequests);
    toast({ title: "Status geändert", description: `Antrag auf "${newStatus}" gesetzt.` });
  };

  const calculateWorkDuration = (startTime, endTime, breakDuration) => {
    if (!endTime) return "Laufend";
    const durationMs = new Date(endTime).getTime() - new Date(startTime).getTime();
    const netDurationMinutes = Math.max(0, (durationMs / (1000 * 60)) - breakDuration);
    const hours = Math.floor(netDurationMinutes / 60);
    const minutes = Math.round(netDurationMinutes % 60);
    return `${hours} Std. ${minutes} Min.`;
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
      <Card className="glassmorphism shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center"><UserCog className="mr-2 h-6 w-6 text-purple-400" />Admin Dashboard</CardTitle>
          <CardDescription>Verwalten Sie Mitarbeiterzeiten und Urlaubsanträge.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="timeEntries" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-purple-500/10">
              <TabsTrigger value="timeEntries" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">Zeiteinträge</TabsTrigger>
              <TabsTrigger value="vacationRequests" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white">Urlaubsanträge</TabsTrigger>
            </TabsList>
            <TabsContent value="timeEntries" className="mt-4">
              <h3 className="text-xl font-semibold mb-2 text-purple-300">Alle Zeiteinträge</h3>
              {allTimeEntries.length === 0 ? (
                <p className="text-slate-400">Keine Einträge vorhanden.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mitarbeiter</TableHead>
                      <TableHead>Datum</TableHead>
                      <TableHead>Start</TableHead>
                      <TableHead>Ende</TableHead>
                      <TableHead>Pause</TableHead>
                      <TableHead>Dauer</TableHead>
                      <TableHead>Aktionen</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allTimeEntries.map(entry => (
                      <TableRow key={entry.id}>
                        <TableCell>{entry.employeeName}</TableCell>
                        <TableCell>{format(new Date(entry.startTime), 'dd.MM.yyyy')}</TableCell>
                        <TableCell>{format(new Date(entry.startTime), 'HH:mm')}</TableCell>
                        <TableCell>{entry.endTime ? format(new Date(entry.endTime), 'HH:mm') : '-'}</TableCell>
                        <TableCell>{entry.breakDuration} Min.</TableCell>
                        <TableCell>{calculateWorkDuration(entry.startTime, entry.endTime, entry.breakDuration)}</TableCell>
                        <TableCell className="space-x-2">
                          <Button variant="outline" size="sm" onClick={() => handleEdit(entry)} className="text-blue-400 border-blue-400 hover:bg-blue-400/20">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                           <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="text-red-400 border-red-400 hover:bg-red-400/20">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[425px] bg-slate-800 border-purple-700">
                              <DialogHeader>
                                <DialogTitle className="text-purple-300">Eintrag löschen</DialogTitle>
                                <DialogDescription className="text-slate-400">
                                  Sind Sie sicher, dass Sie diesen Zeiteintrag löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.
                                </DialogDescription>
                              </DialogHeader>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button type="button" variant="secondary">Abbrechen</Button>
                                </DialogClose>
                                <Button type="button" variant="destructive" onClick={() => handleDelete(entry)}>Löschen</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
            <TabsContent value="vacationRequests" className="mt-4">
              <h3 className="text-xl font-semibold mb-2 text-purple-300">Alle Urlaubsanträge</h3>
              {allVacationRequests.length === 0 ? (
                <p className="text-slate-400">Keine Urlaubsanträge vorhanden.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mitarbeiter</TableHead>
                      <TableHead>Startdatum</TableHead>
                      <TableHead>Enddatum</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Aktionen</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allVacationRequests.map(req => (
                      <TableRow key={req.id}>
                        <TableCell>{req.employeeName}</TableCell>
                        <TableCell>{format(new Date(req.startDate), 'dd.MM.yyyy')}</TableCell>
                        <TableCell>{format(new Date(req.endDate), 'dd.MM.yyyy')}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold
                            ${req.status === 'Approved' ? 'bg-green-500/20 text-green-300' : 
                              req.status === 'Rejected' ? 'bg-red-500/20 text-red-300' :
                              'bg-yellow-500/20 text-yellow-300'}`}>
                            {req.status === 'Pending' ? 'Ausstehend' : req.status === 'Approved' ? 'Genehmigt' : 'Abgelehnt'}
                          </span>
                        </TableCell>
                        <TableCell className="space-x-1">
                          <Button size="sm" variant="outline" className="text-green-400 border-green-400 hover:bg-green-400/20" onClick={() => handleVacationStatusChange(req.id, 'Approved')} disabled={req.status === 'Approved'}>Genehmigen</Button>
                          <Button size="sm" variant="outline" className="text-red-400 border-red-400 hover:bg-red-400/20" onClick={() => handleVacationStatusChange(req.id, 'Rejected')} disabled={req.status === 'Rejected'}>Ablehnen</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {editingEntry && (
        <Dialog open={!!editingEntry} onOpenChange={() => setEditingEntry(null)}>
          <DialogContent className="sm:max-w-[425px] bg-slate-800 border-purple-700">
            <DialogHeader>
              <DialogTitle className="text-purple-300">Zeiteintrag bearbeiten</DialogTitle>
              <DialogDescription className="text-slate-400">
                Bearbeiten Sie die Details für den Zeiteintrag von {editingEntry.employeeName}.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="startTime" className="text-right text-slate-300">Startzeit</Label>
                <Input id="startTime" type="datetime-local" value={formData.startTime} onChange={e => setFormData({...formData, startTime: e.target.value})} className="col-span-3 bg-slate-700 border-slate-600 text-white" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="endTime" className="text-right text-slate-300">Endzeit</Label>
                <Input id="endTime" type="datetime-local" value={formData.endTime} onChange={e => setFormData({...formData, endTime: e.target.value})} className="col-span-3 bg-slate-700 border-slate-600 text-white" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="breakDuration" className="text-right text-slate-300">Pause (Min)</Label>
                <Input id="breakDuration" type="number" value={formData.breakDuration} onChange={e => setFormData({...formData, breakDuration: e.target.value})} className="col-span-3 bg-slate-700 border-slate-600 text-white" />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingEntry(null)}>Abbrechen</Button>
              <Button type="submit" onClick={handleSaveEdit} className="bg-purple-600 hover:bg-purple-700">Speichern</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </motion.div>
  );
}

function VacationRequestPage({ currentUser }) {
  const { toast } = useToast();
  const [vacationRequests, setVacationRequests] = React.useState(() => JSON.parse(localStorage.getItem(`vacationRequests_${currentUser.id}`)) || []);
  const [selectedDateRange, setSelectedDateRange] = React.useState({ from: undefined, to: undefined });

  React.useEffect(() => {
    localStorage.setItem(`vacationRequests_${currentUser.id}`, JSON.stringify(vacationRequests));
  }, [vacationRequests, currentUser.id]);

  const handleDateSelect = (range) => {
    setSelectedDateRange(range);
  };

  const handleSubmitRequest = () => {
    if (!selectedDateRange || !selectedDateRange.from || !selectedDateRange.to) {
      toast({ variant: "destructive", title: "Fehler", description: "Bitte wählen Sie einen Datumsbereich aus." });
      return;
    }
    const newRequest = {
      id: `vac_${Date.now()}`,
      employeeId: currentUser.id,
      startDate: format(selectedDateRange.from, 'yyyy-MM-dd'),
      endDate: format(selectedDateRange.to, 'yyyy-MM-dd'),
      status: 'Pending' 
    };
    setVacationRequests(prev => [newRequest, ...prev]);
    setSelectedDateRange({ from: undefined, to: undefined });
    toast({ title: "Urlaubsantrag gesendet", description: `Antrag für ${format(new Date(newRequest.startDate), 'dd.MM.yyyy')} - ${format(new Date(newRequest.endDate), 'dd.MM.yyyy')} wurde eingereicht.` });
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
      <Card className="glassmorphism shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center"><CalendarDays className="mr-2 h-6 w-6 text-purple-400" />Urlaubsantrag</CardTitle>
          <CardDescription>Beantragen Sie hier Ihren Urlaub.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center md:flex-row md:items-start gap-6">
            <div className="p-2 rounded-md bg-slate-800/70">
              <Calendar
                mode="range"
                selected={selectedDateRange}
                onSelect={handleDateSelect}
                numberOfMonths={1}
                className="text-slate-50"
                classNames={{
                  day_selected: "bg-purple-600 text-white hover:bg-purple-700 focus:bg-purple-700",
                  day_today: "text-purple-400 font-bold",
                  head_cell: "text-slate-400",
                  nav_button: "text-purple-400 hover:bg-purple-500/20",
                }}
              />
            </div>
            <div className="flex-1 w-full">
              {selectedDateRange && selectedDateRange.from && (
                <div className="mb-4 p-3 bg-purple-500/10 rounded-lg">
                  <p className="font-semibold text-purple-300">Ausgewählter Zeitraum:</p>
                  <p className="text-slate-300">
                    Start: {selectedDateRange.from ? format(selectedDateRange.from, 'dd.MM.yyyy') : 'Nicht ausgewählt'}
                  </p>
                  <p className="text-slate-300">
                    Ende: {selectedDateRange.to ? format(selectedDateRange.to, 'dd.MM.yyyy') : 'Nicht ausgewählt'}
                  </p>
                </div>
              )}
              <Button onClick={handleSubmitRequest} disabled={!selectedDateRange || !selectedDateRange.from || !selectedDateRange.to} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 text-lg">
                <Send className="mr-2 h-5 w-5" /> Antrag Senden
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-2 text-purple-300">Meine Urlaubsanträge</h3>
            {vacationRequests.length === 0 ? (
              <p className="text-slate-400">Noch keine Anträge vorhanden.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Startdatum</TableHead>
                    <TableHead>Enddatum</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vacationRequests.map(req => (
                    <TableRow key={req.id}>
                      <TableCell>{format(new Date(req.startDate), 'dd.MM.yyyy')}</TableCell>
                      <TableCell>{format(new Date(req.endDate), 'dd.MM.yyyy')}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold
                          ${req.status === 'Approved' ? 'bg-green-500/20 text-green-300' : 
                            req.status === 'Rejected' ? 'bg-red-500/20 text-red-300' :
                            'bg-yellow-500/20 text-yellow-300'}`}>
                          {req.status === 'Pending' ? 'Ausstehend' : req.status === 'Approved' ? 'Genehmigt' : 'Abgelehnt'}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default App;
