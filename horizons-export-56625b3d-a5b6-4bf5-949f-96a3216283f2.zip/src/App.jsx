
import React, { useState, useEffect } from 'react';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Clock, Calendar, BarChart3, Settings, Plus, Play, Pause, Save, Trash2, Edit, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { TimeTracker } from '@/components/TimeTracker';
import { ProjectList } from '@/components/ProjectList';
import { Reports } from '@/components/Reports';
import { Settings as SettingsPanel } from '@/components/Settings';
import { ThemeProvider } from '@/components/ThemeProvider';

function App() {
  const [activeTab, setActiveTab] = useState('tracker');
  const { toast } = useToast();
  const [timeEntries, setTimeEntries] = useState([]);
  const [projects, setProjects] = useState([]);

  // Load data from localStorage on initial render
  useEffect(() => {
    const savedEntries = localStorage.getItem('timeEntries');
    const savedProjects = localStorage.getItem('projects');
    
    if (savedEntries) {
      try {
        setTimeEntries(JSON.parse(savedEntries));
      } catch (error) {
        console.error('Failed to parse time entries:', error);
        toast({
          title: "Fehler beim Laden der Zeiteinträge",
          description: "Ihre gespeicherten Zeiteinträge konnten nicht geladen werden.",
          variant: "destructive",
        });
      }
    }
    
    if (savedProjects) {
      try {
        setProjects(JSON.parse(savedProjects));
      } catch (error) {
        console.error('Failed to parse projects:', error);
        toast({
          title: "Fehler beim Laden der Projekte",
          description: "Ihre gespeicherten Projekte konnten nicht geladen werden.",
          variant: "destructive",
        });
      }
    } else {
      // Initialize with default projects if none exist
      const defaultProjects = [
        { id: '1', name: 'Allgemein', color: '#4f46e5' },
        { id: '2', name: 'Meetings', color: '#10b981' },
        { id: '3', name: 'Entwicklung', color: '#f59e0b' }
      ];
      setProjects(defaultProjects);
      localStorage.setItem('projects', JSON.stringify(defaultProjects));
    }
  }, [toast]);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('timeEntries', JSON.stringify(timeEntries));
  }, [timeEntries]);

  useEffect(() => {
    localStorage.setItem('projects', JSON.stringify(projects));
  }, [projects]);

  const addTimeEntry = (entry) => {
    const newEntries = [...timeEntries, entry];
    setTimeEntries(newEntries);
    toast({
      title: "Zeiteintrag gespeichert",
      description: `${entry.duration} für ${entry.projectName || 'Unbenanntes Projekt'} erfasst.`,
    });
  };

  const updateTimeEntry = (id, updatedEntry) => {
    const newEntries = timeEntries.map(entry => 
      entry.id === id ? { ...entry, ...updatedEntry } : entry
    );
    setTimeEntries(newEntries);
    toast({
      title: "Zeiteintrag aktualisiert",
      description: "Der Zeiteintrag wurde erfolgreich aktualisiert.",
    });
  };

  const deleteTimeEntry = (id) => {
    const newEntries = timeEntries.filter(entry => entry.id !== id);
    setTimeEntries(newEntries);
    toast({
      title: "Zeiteintrag gelöscht",
      description: "Der Zeiteintrag wurde erfolgreich gelöscht.",
    });
  };

  const addProject = (project) => {
    const newProjects = [...projects, project];
    setProjects(newProjects);
    toast({
      title: "Projekt erstellt",
      description: `Projekt "${project.name}" wurde erfolgreich erstellt.`,
    });
  };

  const updateProject = (id, updatedProject) => {
    const newProjects = projects.map(project => 
      project.id === id ? { ...project, ...updatedProject } : project
    );
    setProjects(newProjects);
    
    // Also update project references in time entries
    const updatedEntries = timeEntries.map(entry => {
      if (entry.projectId === id) {
        return {
          ...entry,
          projectName: updatedProject.name,
          projectColor: updatedProject.color
        };
      }
      return entry;
    });
    
    setTimeEntries(updatedEntries);
    toast({
      title: "Projekt aktualisiert",
      description: `Projekt "${updatedProject.name}" wurde erfolgreich aktualisiert.`,
    });
  };

  const deleteProject = (id) => {
    // Don't delete if there are time entries using this project
    const entriesWithProject = timeEntries.filter(entry => entry.projectId === id);
    if (entriesWithProject.length > 0) {
      toast({
        title: "Projekt kann nicht gelöscht werden",
        description: `Es gibt ${entriesWithProject.length} Zeiteinträge, die diesem Projekt zugeordnet sind.`,
        variant: "destructive",
      });
      return;
    }
    
    const newProjects = projects.filter(project => project.id !== id);
    setProjects(newProjects);
    toast({
      title: "Projekt gelöscht",
      description: "Das Projekt wurde erfolgreich gelöscht.",
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'tracker':
        return (
          <TimeTracker 
            projects={projects} 
            addTimeEntry={addTimeEntry} 
            timeEntries={timeEntries}
            updateTimeEntry={updateTimeEntry}
            deleteTimeEntry={deleteTimeEntry}
          />
        );
      case 'projects':
        return (
          <ProjectList 
            projects={projects} 
            addProject={addProject} 
            updateProject={updateProject} 
            deleteProject={deleteProject}
          />
        );
      case 'reports':
        return <Reports timeEntries={timeEntries} projects={projects} />;
      case 'settings':
        return <SettingsPanel />;
      default:
        return <TimeTracker projects={projects} addTimeEntry={addTimeEntry} />;
    }
  };

  return (
    <ThemeProvider defaultTheme="light">
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-indigo-950">
        <header className="gradient-bg text-white p-4 shadow-lg">
          <div className="container mx-auto flex justify-between items-center">
            <motion.h1 
              className="text-2xl font-bold"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              ZeitErfassung
            </motion.h1>
          </div>
        </header>
        
        <main className="container mx-auto p-4 mt-4">
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl shadow-xl overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </main>
        
        <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg border-t border-gray-200 dark:border-gray-700">
          <div className="container mx-auto flex justify-around">
            <Button 
              variant={activeTab === 'tracker' ? 'default' : 'ghost'} 
              className="flex-1 py-4 rounded-none flex flex-col items-center gap-1"
              onClick={() => setActiveTab('tracker')}
            >
              <Clock className="h-5 w-5" />
              <span className="text-xs">Erfassung</span>
            </Button>
            <Button 
              variant={activeTab === 'projects' ? 'default' : 'ghost'} 
              className="flex-1 py-4 rounded-none flex flex-col items-center gap-1"
              onClick={() => setActiveTab('projects')}
            >
              <Calendar className="h-5 w-5" />
              <span className="text-xs">Projekte</span>
            </Button>
            <Button 
              variant={activeTab === 'reports' ? 'default' : 'ghost'} 
              className="flex-1 py-4 rounded-none flex flex-col items-center gap-1"
              onClick={() => setActiveTab('reports')}
            >
              <BarChart3 className="h-5 w-5" />
              <span className="text-xs">Berichte</span>
            </Button>
            <Button 
              variant={activeTab === 'settings' ? 'default' : 'ghost'} 
              className="flex-1 py-4 rounded-none flex flex-col items-center gap-1"
              onClick={() => setActiveTab('settings')}
            >
              <Settings className="h-5 w-5" />
              <span className="text-xs">Einstellungen</span>
            </Button>
          </div>
        </nav>
        
        <Toaster />
      </div>
    </ThemeProvider>
  );
}

export default App;
