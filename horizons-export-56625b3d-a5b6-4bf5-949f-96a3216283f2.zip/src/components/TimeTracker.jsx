
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, Save, Trash2, Edit, Clock, Calendar, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { formatTime, formatDate } from '@/lib/utils';
import { TimeEntryForm } from '@/components/TimeEntryForm';
import { TimeEntryList } from '@/components/TimeEntryList';

export function TimeTracker({ projects, addTimeEntry, timeEntries, updateTimeEntry, deleteTimeEntry }) {
  const [isRunning, setIsRunning] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [startTime, setStartTime] = useState(null);
  const [selectedProject, setSelectedProject] = useState(projects[0]?.id || null);
  const [description, setDescription] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState(null);
  const timerRef = useRef(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setElapsedTime(prev => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }

    return () => clearInterval(timerRef.current);
  }, [isRunning]);

  const toggleTimer = () => {
    if (isRunning) {
      setIsRunning(false);
    } else {
      setIsRunning(true);
      setStartTime(new Date());
      if (elapsedTime === 0) {
        // Only reset project and description when starting a new timer
        setSelectedProject(projects[0]?.id || null);
        setDescription('');
      }
    }
  };

  const resetTimer = () => {
    setIsRunning(false);
    setElapsedTime(0);
    setStartTime(null);
    setSelectedProject(projects[0]?.id || null);
    setDescription('');
  };

  const saveTimeEntry = () => {
    if (elapsedTime < 60) {
      toast({
        title: "Zu kurze Zeit",
        description: "Die erfasste Zeit sollte mindestens eine Minute betragen.",
        variant: "destructive",
      });
      return;
    }

    const selectedProjectObj = projects.find(p => p.id === selectedProject);
    
    const entry = {
      id: Date.now().toString(),
      startTime: startTime.toISOString(),
      endTime: new Date().toISOString(),
      duration: formatTime(elapsedTime),
      durationSeconds: elapsedTime,
      description: description.trim() || 'Keine Beschreibung',
      projectId: selectedProject,
      projectName: selectedProjectObj?.name || 'Unbenanntes Projekt',
      projectColor: selectedProjectObj?.color || '#4f46e5',
      date: formatDate(new Date())
    };

    addTimeEntry(entry);
    resetTimer();
  };

  const handleEditEntry = (entry) => {
    setEditingEntry(entry);
    setShowForm(true);
  };

  const handleSaveEdit = (updatedEntry) => {
    updateTimeEntry(editingEntry.id, updatedEntry);
    setEditingEntry(null);
    setShowForm(false);
  };

  const handleCancelEdit = () => {
    setEditingEntry(null);
    setShowForm(false);
  };

  const handleManualEntry = () => {
    setShowForm(true);
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">Zeiterfassung</h2>
        
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl p-6 shadow-lg text-white mb-6">
          <div className="flex flex-col items-center">
            <motion.div 
              className="text-5xl font-bold timer-display mb-4"
              key={elapsedTime}
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.2 }}
            >
              {formatTime(elapsedTime)}
            </motion.div>
            
            <div className="flex gap-3 mb-4">
              <Button
                onClick={toggleTimer}
                size="lg"
                className={`rounded-full w-14 h-14 flex items-center justify-center ${
                  isRunning ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'
                }`}
              >
                {isRunning ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
              </Button>
              
              {elapsedTime > 0 && (
                <Button
                  onClick={saveTimeEntry}
                  size="lg"
                  className="rounded-full w-14 h-14 flex items-center justify-center bg-blue-700 hover:bg-blue-800"
                >
                  <Save className="h-6 w-6" />
                </Button>
              )}
            </div>
            
            {elapsedTime > 0 && (
              <div className="w-full max-w-md">
                <div className="flex items-center gap-2 mb-2">
                  <Tag className="h-4 w-4" />
                  <select 
                    value={selectedProject || ''}
                    onChange={(e) => setSelectedProject(e.target.value)}
                    className="w-full bg-white/20 rounded-md border-0 px-3 py-2 text-white placeholder-white/70 focus:ring-2 focus:ring-white"
                  >
                    {projects.map(project => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="flex items-center gap-2">
                  <Edit className="h-4 w-4" />
                  <input 
                    type="text" 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Beschreibung hinzufügen"
                    className="w-full bg-white/20 rounded-md border-0 px-3 py-2 text-white placeholder-white/70 focus:ring-2 focus:ring-white"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Heutige Einträge</h3>
          <Button onClick={handleManualEntry} variant="outline" size="sm" className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>Manueller Eintrag</span>
          </Button>
        </div>
        
        <AnimatePresence>
          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6 overflow-hidden"
            >
              <TimeEntryForm 
                projects={projects}
                onSave={editingEntry ? handleSaveEdit : addTimeEntry}
                onCancel={handleCancelEdit}
                initialValues={editingEntry}
              />
            </motion.div>
          )}
        </AnimatePresence>
        
        <TimeEntryList 
          timeEntries={timeEntries} 
          onEdit={handleEditEntry} 
          onDelete={deleteTimeEntry}
          showDate={true}
        />
      </div>
    </div>
  );
}
