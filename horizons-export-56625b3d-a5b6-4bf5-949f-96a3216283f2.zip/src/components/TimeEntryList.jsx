
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Edit, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/utils';
import { ConfirmDialog } from '@/components/ConfirmDialog';

export function TimeEntryList({ timeEntries, onEdit, onDelete, showDate = false }) {
  const [expandedEntry, setExpandedEntry] = useState(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [entryToDelete, setEntryToDelete] = useState(null);
  
  // Group entries by date if showDate is true
  const groupedEntries = showDate 
    ? timeEntries.reduce((groups, entry) => {
        const date = entry.date || formatDate(new Date(entry.startTime));
        if (!groups[date]) {
          groups[date] = [];
        }
        groups[date].push(entry);
        return groups;
      }, {})
    : { 'all': timeEntries };
  
  // Sort dates in descending order (newest first)
  const sortedDates = Object.keys(groupedEntries).sort((a, b) => {
    if (a === 'all') return -1;
    if (b === 'all') return 1;
    return new Date(b) - new Date(a);
  });
  
  const toggleExpand = (id) => {
    setExpandedEntry(expandedEntry === id ? null : id);
  };
  
  const handleDeleteClick = (e, id) => {
    e.stopPropagation();
    setEntryToDelete(id);
    setConfirmDialogOpen(true);
  };
  
  const handleConfirmDelete = () => {
    if (entryToDelete) {
      onDelete(entryToDelete);
      setEntryToDelete(null);
    }
  };
  
  if (timeEntries.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500 dark:text-gray-400">
        <p>Keine Zeiteinträge vorhanden</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {sortedDates.map(date => (
        <div key={date} className="space-y-2">
          {showDate && date !== 'all' && (
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
              {date === formatDate(new Date()) ? 'Heute' : date}
            </h4>
          )}
          
          <div className="space-y-2">
            <AnimatePresence>
              {groupedEntries[date].map(entry => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden"
                >
                  <div 
                    className="p-4 flex items-center justify-between cursor-pointer"
                    onClick={() => toggleExpand(entry.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: entry.projectColor }}
                      />
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-gray-100">
                          {entry.projectName}
                        </h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {entry.duration}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {entry.description.length > 20 
                          ? `${entry.description.substring(0, 20)}...` 
                          : entry.description}
                      </span>
                      {expandedEntry === entry.id ? (
                        <ChevronUp className="h-4 w-4 text-gray-400" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-gray-400" />
                      )}
                    </div>
                  </div>
                  
                  <AnimatePresence>
                    {expandedEntry === entry.id && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="border-t border-gray-200 dark:border-gray-700 px-4 py-3 bg-gray-50 dark:bg-gray-700/50"
                      >
                        <div className="flex flex-col gap-2">
                          <p className="text-sm text-gray-700 dark:text-gray-300">
                            <span className="font-medium">Beschreibung:</span> {entry.description}
                          </p>
                          
                          <div className="flex justify-end gap-2 mt-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="h-8"
                              onClick={(e) => {
                                e.stopPropagation();
                                onEdit(entry);
                              }}
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Bearbeiten
                            </Button>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              className="h-8"
                              onClick={(e) => handleDeleteClick(e, entry.id)}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Löschen
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      ))}
      
      <ConfirmDialog
        open={confirmDialogOpen}
        onOpenChange={setConfirmDialogOpen}
        title="Zeiteintrag löschen"
        description="Sind Sie sicher, dass Sie diesen Zeiteintrag löschen möchten?"
        confirmText="Löschen"
        cancelText="Abbrechen"
        onConfirm={handleConfirmDelete}
        variant="destructive"
      />
    </div>
  );
}
