
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Download, Upload, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/components/ThemeProvider';
import { useToast } from '@/components/ui/use-toast';
import { ConfirmDialog } from '@/components/ConfirmDialog';

export function Settings() {
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  
  const exportData = () => {
    try {
      const timeEntries = localStorage.getItem('timeEntries') || '[]';
      const projects = localStorage.getItem('projects') || '[]';
      
      const data = {
        timeEntries: JSON.parse(timeEntries),
        projects: JSON.parse(projects),
        exportDate: new Date().toISOString()
      };
      
      const dataStr = JSON.stringify(data, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = `zeiterfassung-export-${new Date().toISOString().slice(0, 10)}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      toast({
        title: "Export erfolgreich",
        description: "Ihre Daten wurden erfolgreich exportiert.",
      });
    } catch (error) {
      console.error('Export failed:', error);
      toast({
        title: "Export fehlgeschlagen",
        description: "Beim Exportieren Ihrer Daten ist ein Fehler aufgetreten.",
        variant: "destructive",
      });
    }
  };
  
  const importData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target.result);
          
          if (!data.timeEntries || !data.projects) {
            throw new Error('Invalid data format');
          }
          
          localStorage.setItem('timeEntries', JSON.stringify(data.timeEntries));
          localStorage.setItem('projects', JSON.stringify(data.projects));
          
          toast({
            title: "Import erfolgreich",
            description: "Ihre Daten wurden erfolgreich importiert. Die Seite wird neu geladen.",
          });
          
          // Reload the page after a short delay to apply imported data
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        } catch (error) {
          console.error('Import failed:', error);
          toast({
            title: "Import fehlgeschlagen",
            description: "Die Datei enthält keine gültigen Daten.",
            variant: "destructive",
          });
        }
      };
      
      reader.readAsText(file);
    };
    
    input.click();
  };
  
  const handleClearDataClick = () => {
    setConfirmDialogOpen(true);
  };
  
  const clearAllData = () => {
    localStorage.removeItem('timeEntries');
    localStorage.removeItem('projects');
    
    toast({
      title: "Daten gelöscht",
      description: "Alle Ihre Daten wurden gelöscht. Die Seite wird neu geladen.",
    });
    
    // Reload the page after a short delay
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  };
  
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">Einstellungen</h2>
      
      <div className="space-y-6">
        <motion.div 
          className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">Erscheinungsbild</h3>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-700 dark:text-gray-300">Dunkelmodus</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Wechseln Sie zwischen hellem und dunklem Design</p>
            </div>
            
            <Button 
              variant="outline" 
              size="icon"
              onClick={toggleTheme}
              className="h-10 w-10 rounded-full"
            >
              {theme === 'dark' ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>
          </div>
        </motion.div>
        
        <motion.div 
          className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">Daten</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-700 dark:text-gray-300">Daten exportieren</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Speichern Sie Ihre Zeiterfassungsdaten als JSON-Datei</p>
              </div>
              
              <Button 
                variant="outline" 
                onClick={exportData}
                className="flex items-center gap-1"
              >
                <Download className="h-4 w-4" />
                <span>Exportieren</span>
              </Button>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-700 dark:text-gray-300">Daten importieren</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Laden Sie zuvor exportierte Daten</p>
              </div>
              
              <Button 
                variant="outline" 
                onClick={importData}
                className="flex items-center gap-1"
              >
                <Upload className="h-4 w-4" />
                <span>Importieren</span>
              </Button>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-700 dark:text-gray-300">Alle Daten löschen</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 text-red-500">Achtung: Diese Aktion kann nicht rückgängig gemacht werden</p>
              </div>
              
              <Button 
                variant="destructive" 
                onClick={handleClearDataClick}
                className="flex items-center gap-1"
              >
                <Trash2 className="h-4 w-4" />
                <span>Löschen</span>
              </Button>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">Über</h3>
          
          <div className="text-gray-700 dark:text-gray-300">
            <p>ZeitErfassung v1.0.0</p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Eine einfache Zeiterfassungs-App für Ihre täglichen Aufgaben.
            </p>
          </div>
        </motion.div>
      </div>
      
      <ConfirmDialog
        open={confirmDialogOpen}
        onOpenChange={setConfirmDialogOpen}
        title="Alle Daten löschen"
        description="Sind Sie sicher, dass Sie alle Daten löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden."
        confirmText="Löschen"
        cancelText="Abbrechen"
        onConfirm={clearAllData}
        variant="destructive"
      />
    </div>
  );
}
