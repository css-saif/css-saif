
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Edit, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ConfirmDialog } from '@/components/ConfirmDialog';

export function ProjectList({ projects, addProject, updateProject, deleteProject }) {
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [name, setName] = useState('');
  const [color, setColor] = useState('#4f46e5');
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);
  const { toast } = useToast();
  
  const handleAddClick = () => {
    setEditingProject(null);
    setName('');
    setColor('#4f46e5');
    setShowForm(true);
  };
  
  const handleEditClick = (project) => {
    setEditingProject(project);
    setName(project.name);
    setColor(project.color);
    setShowForm(true);
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Fehler",
        description: "Bitte geben Sie einen Projektnamen ein.",
        variant: "destructive",
      });
      return;
    }
    
    if (editingProject) {
      updateProject(editingProject.id, {
        ...editingProject,
        name: name.trim(),
        color
      });
    } else {
      addProject({
        id: Date.now().toString(),
        name: name.trim(),
        color
      });
    }
    
    setShowForm(false);
    setName('');
    setColor('#4f46e5');
    setEditingProject(null);
  };
  
  const handleCancel = () => {
    setShowForm(false);
    setEditingProject(null);
  };
  
  const handleDeleteClick = (id) => {
    setProjectToDelete(id);
    setConfirmDialogOpen(true);
  };
  
  const handleConfirmDelete = () => {
    if (projectToDelete) {
      deleteProject(projectToDelete);
      setProjectToDelete(null);
    }
  };
  
  const colorOptions = [
    '#4f46e5', // Indigo
    '#10b981', // Emerald
    '#f59e0b', // Amber
    '#ef4444', // Red
    '#8b5cf6', // Violet
    '#ec4899', // Pink
    '#06b6d4', // Cyan
    '#84cc16', // Lime
  ];
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100">Projekte</h2>
        <Button onClick={handleAddClick} className="flex items-center gap-1">
          <Plus className="h-4 w-4" />
          <span>Neues Projekt</span>
        </Button>
      </div>
      
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-6 overflow-hidden"
          >
            <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 mb-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium text-gray-900 dark:text-gray-100">
                  {editingProject ? 'Projekt bearbeiten' : 'Neues Projekt'}
                </h3>
                <Button variant="ghost" size="sm" onClick={handleCancel} className="h-8 w-8 p-0">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Projektname
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Projektname eingeben"
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Farbe
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {colorOptions.map((colorOption) => (
                        <button
                          key={colorOption}
                          type="button"
                          className={`w-8 h-8 rounded-full border-2 ${
                            color === colorOption ? 'border-gray-900 dark:border-white' : 'border-transparent'
                          }`}
                          style={{ backgroundColor: colorOption }}
                          onClick={() => setColor(colorOption)}
                        />
                      ))}
                      <input
                        type="color"
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        className="w-8 h-8 rounded-full cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end gap-2 mt-4">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Abbrechen
                  </Button>
                  <Button type="submit">
                    {editingProject ? 'Aktualisieren' : 'Speichern'}
                  </Button>
                </div>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <div className="space-y-4">
        {projects.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <p>Keine Projekte vorhanden</p>
          </div>
        ) : (
          <AnimatePresence>
            {projects.map(project => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-4 h-4 rounded-full" 
                    style={{ backgroundColor: project.color }}
                  />
                  <span className="font-medium text-gray-900 dark:text-gray-100">
                    {project.name}
                  </span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => handleEditClick(project)}
                  >
                    <Edit className="h-4 w-4 text-gray-500" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => handleDeleteClick(project.id)}
                  >
                    <Trash2 className="h-4 w-4 text-gray-500" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
      
      <ConfirmDialog
        open={confirmDialogOpen}
        onOpenChange={setConfirmDialogOpen}
        title="Projekt löschen"
        description="Sind Sie sicher, dass Sie dieses Projekt löschen möchten?"
        confirmText="Löschen"
        cancelText="Abbrechen"
        onConfirm={handleConfirmDelete}
        variant="destructive"
      />
    </div>
  );
}
