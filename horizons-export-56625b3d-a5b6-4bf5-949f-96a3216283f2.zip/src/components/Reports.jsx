
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, BarChart3, PieChart, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatTime, formatDate, generateMonthlyReport, generatePDF } from '@/lib/utils';

export function Reports({ timeEntries, projects }) {
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  const [filteredEntries, setFilteredEntries] = useState([]);
  const [totalTime, setTotalTime] = useState(0);
  const [projectTotals, setProjectTotals] = useState([]);
  const [dailyTotals, setDailyTotals] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(formatDate(new Date()).substring(0, 7));
  
  useEffect(() => {
    const now = new Date();
    let startDate;
    
    switch (selectedPeriod) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        const day = now.getDay();
        const diff = now.getDate() - day + (day === 0 ? -6 : 1);
        startDate = new Date(now.getFullYear(), now.getMonth(), diff);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }
    
    const filtered = timeEntries.filter(entry => {
      const entryDate = new Date(entry.startTime);
      return entryDate >= startDate && entryDate <= now;
    });
    
    setFilteredEntries(filtered);
    
    const total = filtered.reduce((sum, entry) => sum + (entry.durationSeconds || 0), 0);
    setTotalTime(total);
    
    const projectSums = {};
    filtered.forEach(entry => {
      const projectId = entry.projectId;
      if (!projectSums[projectId]) {
        projectSums[projectId] = 0;
      }
      projectSums[projectId] += (entry.durationSeconds || 0);
    });
    
    const projectTotalsArray = Object.keys(projectSums).map(projectId => {
      const project = projects.find(p => p.id === projectId) || { 
        name: 'Unbekanntes Projekt', 
        color: '#888888' 
      };
      return {
        projectId,
        projectName: project.name,
        projectColor: project.color,
        totalSeconds: projectSums[projectId],
        percentage: (projectSums[projectId] / (total || 1)) * 100
      };
    }).sort((a, b) => b.totalSeconds - a.totalSeconds);
    
    setProjectTotals(projectTotalsArray);
    
    const dailySums = {};
    let currentDate = new Date(startDate);
    while (currentDate <= now) {
      const dateStr = formatDate(currentDate);
      dailySums[dateStr] = 0;
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    filtered.forEach(entry => {
      const dateStr = entry.date || formatDate(new Date(entry.startTime));
      if (!dailySums[dateStr]) {
        dailySums[dateStr] = 0;
      }
      dailySums[dateStr] += (entry.durationSeconds || 0);
    });
    
    const dailyTotalsArray = Object.keys(dailySums).map(date => ({
      date,
      totalSeconds: dailySums[date],
      totalHours: dailySums[date] / 3600
    })).sort((a, b) => new Date(a.date) - new Date(b.date));
    
    setDailyTotals(dailyTotalsArray);
    
  }, [timeEntries, selectedPeriod, projects]);

  const handleExportPDF = () => {
    const reportData = generateMonthlyReport(timeEntries, projects, selectedMonth);
    generatePDF(reportData);
  };
  
  const renderBarChart = () => {
    if (dailyTotals.length === 0) return null;
    
    const maxHours = Math.max(...dailyTotals.map(day => day.totalHours), 8);
    const chartHeight = 200;
    
    return (
      <div className="mt-6">
        <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">Tägliche Arbeitszeit</h3>
        <div className="relative h-[200px]">
          <div className="absolute left-0 top-0 bottom-0 flex flex-col justify-between text-xs text-gray-500 dark:text-gray-400">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center">
                <span className="mr-1">{Math.round((maxHours / 4) * (4 - i))}h</span>
                <div className="w-full border-t border-gray-200 dark:border-gray-700" />
              </div>
            ))}
          </div>
          
          <div className="ml-8 h-full flex items-end space-x-2">
            {dailyTotals.map((day, index) => {
              const height = (day.totalHours / maxHours) * chartHeight;
              const isToday = day.date === formatDate(new Date());
              
              return (
                <div key={index} className="flex flex-col items-center">
                  <motion.div 
                    initial={{ height: 0 }}
                    animate={{ height }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                    className={`w-8 rounded-t-md ${
                      isToday ? 'bg-blue-500' : 'bg-blue-300 dark:bg-blue-700'
                    }`}
                  />
                  <div className="text-xs text-gray-500 dark:text-gray-400 mt-1 transform -rotate-45 origin-top-left">
                    {new Date(day.date).toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric' })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };
  
  const renderPieChart = () => {
    if (projectTotals.length === 0) return null;
    
    let cumulativePercentage = 0;
    
    return (
      <div className="mt-8">
        <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">Verteilung nach Projekten</h3>
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="relative w-48 h-48">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {projectTotals.map((project, index) => {
                const startAngle = cumulativePercentage * 3.6;
                cumulativePercentage += project.percentage;
                const endAngle = cumulativePercentage * 3.6;
                
                const startX = 50 + 50 * Math.cos((startAngle - 90) * (Math.PI / 180));
                const startY = 50 + 50 * Math.sin((startAngle - 90) * (Math.PI / 180));
                const endX = 50 + 50 * Math.cos((endAngle - 90) * (Math.PI / 180));
                const endY = 50 + 50 * Math.sin((endAngle - 90) * (Math.PI / 180));
                
                const largeArcFlag = project.percentage > 50 ? 1 : 0;
                
                const pathData = [
                  `M 50 50`,
                  `L ${startX} ${startY}`,
                  `A 50 50 0 ${largeArcFlag} 1 ${endX} ${endY}`,
                  `Z`
                ].join(' ');
                
                return (
                  <motion.path
                    key={index}
                    d={pathData}
                    fill={project.projectColor}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  />
                );
              })}
            </svg>
          </div>
          
          <div className="flex flex-col gap-2">
            {projectTotals.map((project, index) => (
              <div key={index} className="flex items-center gap-2">
                <div 
                  className="w-4 h-4 rounded-full" 
                  style={{ backgroundColor: project.projectColor }}
                />
                <span className="text-sm text-gray-800 dark:text-gray-200">
                  {project.projectName}
                </span>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {formatTime(project.totalSeconds)} ({project.percentage.toFixed(1)}%)
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100">Berichte</h2>
        
        <div className="flex items-center gap-4">
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800"
          />
          <Button 
            onClick={handleExportPDF}
            className="flex items-center gap-2"
          >
            <FileText className="h-4 w-4" />
            <span>PDF Export</span>
          </Button>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-wrap gap-2 mb-6">
          <Button 
            variant={selectedPeriod === 'today' ? 'default' : 'outline'} 
            onClick={() => setSelectedPeriod('today')}
            className="flex items-center gap-1"
          >
            <Calendar className="h-4 w-4" />
            <span>Heute</span>
          </Button>
          <Button 
            variant={selectedPeriod === 'week' ? 'default' : 'outline'} 
            onClick={() => setSelectedPeriod('week')}
            className="flex items-center gap-1"
          >
            <Calendar className="h-4 w-4" />
            <span>Diese Woche</span>
          </Button>
          <Button 
            variant={selectedPeriod === 'month' ? 'default' : 'outline'} 
            onClick={() => setSelectedPeriod('month')}
            className="flex items-center gap-1"
          >
            <Calendar className="h-4 w-4" />
            <span>Dieser Monat</span>
          </Button>
          <Button 
            variant={selectedPeriod === 'year' ? 'default' : 'outline'} 
            onClick={() => setSelectedPeriod('year')}
            className="flex items-center gap-1"
          >
            <Calendar className="h-4 w-4" />
            <span>Dieses Jahr</span>
          </Button>
        </div>
        
        {filteredEntries.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <p>Keine Daten für den ausgewählten Zeitraum verfügbar</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl p-6 text-white">
                <div className="flex items-center gap-3 mb-2">
                  <Clock className="h-6 w-6" />
                  <h3 className="text-lg font-medium">Gesamtzeit</h3>
                </div>
                <p className="text-3xl font-bold">{formatTime(totalTime)}</p>
              </div>
              
              <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl p-6 text-white">
                <div className="flex items-center gap-3 mb-2">
                  <BarChart3 className="h-6 w-6" />
                  <h3 className="text-lg font-medium">Einträge</h3>
                </div>
                <p className="text-3xl font-bold">{filteredEntries.length}</p>
              </div>
            </div>
            
            {renderBarChart()}
            {renderPieChart()}
          </>
        )}
      </div>
    </div>
  );
}
