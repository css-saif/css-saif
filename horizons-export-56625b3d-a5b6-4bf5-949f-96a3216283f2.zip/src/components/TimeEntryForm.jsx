
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { formatTime, formatDate } from '@/lib/utils';
import { X } from 'lucide-react';

export function TimeEntryForm({ projects, onSave, onCancel, initialValues = null }) {
  const [hours, setHours] = useState('00');
  const [minutes, setMinutes] = useState('00');
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState('');
  const [date, setDate] = useState(formatDate(new Date()));
  
  useEffect(() => {
    if (initialValues) {
      // Convert duration seconds to hours and minutes
      const totalSeconds = initialValues.durationSeconds || 0;
      const hrs = Math.floor(totalSeconds / 3600);
      const mins = Math.floor((totalSeconds % 3600) / 60);
      
      setHours(hrs.toString().padStart(2, '0'));
      setMinutes(mins.toString().padStart(2, '0'));
      setDescription(initialValues.description || '');
      setProjectId(initialValues.projectId || projects[0]?.id || '');
      setDate(initialValues.date || formatDate(new Date()));
    } else {
      setProjectId(projects[0]?.id || '');
    }
  }, [initialValues, projects]);
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    const hoursNum = parseInt(hours, 10) || 0;
    const minutesNum = parseInt(minutes, 10) || 0;
    const totalSeconds = (hoursNum * 3600) + (minutesNum * 60);
    
    if (totalSeconds === 0) {
      alert('Bitte geben Sie eine gültige Zeit ein');
      return;
    }
    
    const selectedProject = projects.find(p => p.id === projectId);
    const now = new Date();
    const entryDate = new Date(date);
    
    // Create end time based on the selected date and current time
    entryDate.setHours(now.getHours(), now.getMinutes(), now.getSeconds());
    const endTime = new Date(entryDate);
    
    // Calculate start time by subtracting the duration
    const startTime = new Date(endTime);
    startTime.setSeconds(startTime.getSeconds() - totalSeconds);
    
    const entry = {
      id: initialValues?.id || Date.now().toString(),
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      duration: formatTime(totalSeconds),
      durationSeconds: totalSeconds,
      description: description.trim() || 'Keine Beschreibung',
      projectId: projectId,
      projectName: selectedProject?.name || 'Unbenanntes Projekt',
      projectColor: selectedProject?.color || '#4f46e5',
      date: date
    };
    
    onSave(entry);
    
    // Reset form if not editing
    if (!initialValues) {
      setHours('00');
      setMinutes('00');
      setDescription('');
      setProjectId(projects[0]?.id || '');
      setDate(formatDate(new Date()));
    }
  };
  
  return (
    <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 mb-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium text-gray-900 dark:text-gray-100">
          {initialValues ? 'Zeiteintrag bearbeiten' : 'Neuer Zeiteintrag'}
        </h3>
        <Button variant="ghost" size="sm" onClick={onCancel} className="h-8 w-8 p-0">
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Datum
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Projekt
            </label>
            <select
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            >
              {projects.map(project => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Dauer
            </label>
            <div className="flex items-center">
              <input
                type="number"
                min="0"
                max="23"
                value={hours}
                onChange={(e) => setHours(e.target.value.padStart(2, '0'))}
                className="w-16 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
              <span className="mx-2 text-gray-500 dark:text-gray-400">:</span>
              <input
                type="number"
                min="0"
                max="59"
                value={minutes}
                onChange={(e) => setMinutes(e.target.value.padStart(2, '0'))}
                className="w-16 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
              <span className="ml-2 text-gray-500 dark:text-gray-400">Std:Min</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Beschreibung
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Was haben Sie gemacht?"
              className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            Abbrechen
          </Button>
          <Button type="submit">
            {initialValues ? 'Aktualisieren' : 'Speichern'}
          </Button>
        </div>
      </form>
    </div>
  );
}
